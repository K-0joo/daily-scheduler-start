/* 그룹 생성 
 */
package Login;

import java.util.List;

/**
 *
 * @author 영
 */
public class GroupList {
    private String Group;
    private String list;
    
    public String getGroup(){
        return Group;
    }

    public void setGroup(String Group){
        this.Group = Group;
    }
    
    public String getlist(){
        return list;
    } 
    
    public void setlist(String list){
        this.list = list;
    }
    
}


