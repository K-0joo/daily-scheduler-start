/* 시작화면
 */
package Login;

import javax.swing.JFrame;
//import javax.swing.JPanel;
//import javax.swing.JButton;
//import java.awt.BorderLayout;
import java.awt.Frame;
//import javax.swing.*;
//import java.awt.*;
/**
 *
 * @author 영
 */
public class Start_Page extends JFrame {

    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
             
        // TODO code application logic here
       LogIn lg = new LogIn();
       lg.setVisible(true);//창을 화면에 나타내는 지 유무
       lg.pack();//윈도우의 사이즈를 맞추기
       lg.setLocationRelativeTo(null);//화면 정중앙에 프레임 위치 띄우기
       lg.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//메인 프레임을 닫을 때 프로그램도 닫는 것

    }  
}
